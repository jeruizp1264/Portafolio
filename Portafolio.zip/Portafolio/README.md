# Jorge_Ruiz
Mi portafolio utilizando HTML, CSS y JavaScript
imagenes desde https://fontawesome.com/icons
Estilos https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model
